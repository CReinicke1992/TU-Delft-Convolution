close all
clear

%% Modelling parameters

dt = 0.003;     % Time sample duration in seconds
f0 = 30;        % Central frequency of the wavelet in Hz
nt = 256;       % Number of time samples (positive and negative time!)
nf = nt/2+1;    % Number of frequency samples (usually there are as many 
                % frequency samples as time samples, however, I only
                % consider positive frequencies. Thus, I divide by zero,
                % then I add one to include zero-frequency)

% Build a time vector                
t = dt*(0:nf-1);
t = [t,-t(end-1:-1:2)]; 
% The time vector has this structure: 
% [0, dt, 2*dt, 3*dt, ...., tmax, -tmax, -(tmax-dt), ..., -2*dt, -dt]
% This structure might no tbe the most intuitive one, but it is standard in
% Matlab.


%% Wavelet

% The function ricker.m builds a ricker wavelet with central frequency f0,
% nt time samples and a time sample duration of dt.
w = ricker(f0,nt,dt);

% For plotting the vectors are shifted in such a way that time zero is in
% the center.
t = circshift(t,[0,nf-2]);
w = circshift(w,[nf-2,0]);

% Temporal derivative of the wavelet (to make the wavelet assymetric in
% time, for better illustration)
w = [diff(w);0];

% Minimum phase wavelet: Shift the wavelet to make sure there is no energy,
% i.e. for times smaller than zero all amplitudes should equal zero.
shift = find(abs(w) > 0.001*max(w),1);
shift = shift - nf + 1;
w = circshift(w,[-shift,0]);

% Half zero phase (for stricter causality)
% w(1:nf-1)=0;

% Plot the wavelet
% figure; plot(t,w); xlabel('Time (s)')

%% Reflectivity

% Insert 3 reflectors (randomly)
r = zeros(nf,1);
r(15) = 1;
r(51) = -0.25;
r(101) = 0.1;

% figure; plot(t(nf-1:end),r); xlabel('Time (s)'); ylabel('Reflectivity');

%% Convolution

% Pre-allocate the convolution output
con = zeros(nt,1);

% Flip the source wavelet (input) in time
w_rev = flipud(w);

% Name the output video
file = sprintf('RickerDerivative_%dHz.mp4',f0);
v=VideoWriter(file,'MPEG-4');%'Uncompressed AVI');

% Set a frame rate for the video
v.FrameRate = 15;
open(v);

for it = nf+1:nt
    
   % Determine the shift of the wavelet (input) 
   tmp = it-nf; 
   
   % Multipply the shifted wavelet (input) elementwise with the
   % reflectivity and sum the elements of the resulting vector
   % The result is the value of the convolution-series for the shift
   % position tmp
   new_pt = sum(w_rev(end+1-it+1:end-tmp+1).*r(:)); 
   con(it) = new_pt;
   
   % Plot the wavelet (input)
   subplot(4,1,1)
   plot(t,w,'LineWidth',2); title('Input')
   axis([t(1) t(end) -0.5 1])
   set(gca,'fontsize',18)
   
   % Plot the time-reversed wavelet
   subplot(4,1,2)
   plot(t,w_rev,'LineWidth',2); title('Time-reversed input')
   axis([t(1) t(end) -0.5 1])
   set(gca,'fontsize',18)
   
   % Plot the reversed and shifted wavelet, the reflectivity, and their
   % overlap
   overlap = r.*w_rev(end+1-it:end-tmp);
   subplot(4,1,3)
   plot(t(nf-1:end),r,'LineWidth',2);hold on;
   plot(t(nf-1:end),w_rev(end+1-it:end-tmp),'LineWidth',2);hold on;
   area(t(nf-1:end),overlap,'LineWidth',2); hold off;
   title('Shift, multiply with G, and add');
   axis([t(nf+1) t(end) -0.5 1])
   set(gca,'fontsize',18)
   
   % Plot the convolution-series
   subplot(4,1,4)
   plot(t(nf+1:it),con(nf+1:it),'LineWidth',2);
   title('Output')
   axis([t(nf+1) t(end) -0.5 1])
   set(gca,'fontsize',18)
   %end
   
   F = getframe(gcf);
    writeVideo(v,F);
end
close(v);

% Plot the final output of the convolution-series
% out = con(nf-1:end);
% figure; plot(t(nf-1:end),out);